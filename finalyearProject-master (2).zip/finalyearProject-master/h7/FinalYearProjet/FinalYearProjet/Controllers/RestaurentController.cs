﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalYearProjet.Models;


namespace FinalYearProjet.Controllers
{
    public class RestaurentController : Controller
    {
        public ViewResult PendingOrder()
        {

            return View("PendingOrder",RestaurentRepository.restaurantPendingOrder);

        }
        public ViewResult ConfirmOrder()
        {

            return View("ConfirmOrder");

        }
        //cart.OrderAccept = 0;
                //cart.OrderReceived = 0;
        public ViewResult PlaceOrder()
        {
            Receipt receipt = new Receipt();
            receipt.ReceiptID = RestaurentRepository.restaurantPendingOrder.Count + 1;
            receipt.OrderTime = DateTime.Now;
            receipt.NoOfItems = RestaurentRepository.Cart.Count;
            receipt.OrderAccept = 0;
            receipt.OrderReceived = 0;
            receipt.TotalAmount = 0.ToString();

            foreach (CartAndOrder cart in RestaurentRepository.Cart)
            {
                receipt.UserID = cart.UserID;
                cart.ReceiptID = receipt.ReceiptID;
                receipt.TotalAmount = (Int32.Parse(receipt.TotalAmount)+   Int32.Parse(cart.Price)).ToString();
                RestaurentRepository.AddOrderD(cart);
                RestaurentRepository.order.Add(cart);

            }
            RestaurentRepository.restaurantPendingOrder.Add(receipt);
            RestaurentRepository.Cart.Clear();

            return View("PendingOrder", RestaurentRepository.restaurantPendingOrder);
        }
        public ViewResult UserOrderList()
        {

            return View("UserOrderList",RestaurentRepository.restaurantOrderList);

        }
        public ViewResult Detail(int ReceiptID)
        {
            ViewBag.ReceiptID = ReceiptID;
            return View("Detail",RestaurentRepository.order);

        }

        public ViewResult Remove(int CartID)
        {
            CartAndOrder r = RestaurentRepository.Cart.Find(r => r.CartID == CartID);
            RestaurentRepository.Cart.Remove(r);
            RestaurentRepository.RemoveCart(r.CartID);
            return View("RestaurentCartView", RestaurentRepository.Cart);

        }
        public ViewResult CLear()
        {
            RestaurentRepository.Cart.Clear();
            RestaurentRepository.ClearAllCart();

            return View("RestaurentCartView", RestaurentRepository.Cart);

        }
        
        public ViewResult Increase(int CartID)
        {
            CartAndOrder r = RestaurentRepository.Cart.Find(r => r.CartID == CartID);


            foreach (CartAndOrder cart in RestaurentRepository.Cart)
            {

                if (cart.CartID == r.CartID)
                {

                    cart.Price = (Int32.Parse(r.OriginalPrice) * (r.Quantity + 1)).ToString();
                    cart.Quantity = r.Quantity + 1;
                    break;
                }

            }
            RestaurentRepository.EditCart(r);
            return View("RestaurentCartView", RestaurentRepository.Cart);

        }
        public ViewResult Decrease(int CartID)
        {
            CartAndOrder r = RestaurentRepository.Cart.Find(r => r.CartID == CartID);
            if(r.Quantity==1)
            {
                Remove(CartID);
                return View("RestaurentCartView", RestaurentRepository.Cart);

            }

            foreach (CartAndOrder cart in RestaurentRepository.Cart)
            {

                if (cart.CartID == r.CartID)
                {

                    cart.Price = (Int32.Parse(r.OriginalPrice) *(r.Quantity-1)).ToString();
                    cart.Quantity = r.Quantity - 1;
                    break;
                }

            }
            RestaurentRepository.EditCart(r);
            return View("RestaurentCartView", RestaurentRepository.Cart);


        }
        [HttpPost]
        public ViewResult AddToCart(RestaurentMenu r)
        {
            RestaurentMenu rm = RestaurentRepository.restaurentsMenu.Find(rm => rm.RestaurentID == r.RestaurentID && rm.MenuID == r.MenuID);


            CartAndOrder a = new CartAndOrder();
            a.CartID = RestaurentRepository.Cart.Count + 1;
            a.RestaurentID = rm.RestaurentID;
            //a.Quantity = Convert.ToInt32(Request["TextQuintity"].ToString());
            a.Quantity = r.SelectedQuantity;
            a.OriginalPrice = rm.Price;
            a.Price = (Int32.Parse( rm.Price)*a.Quantity).ToString();
            a.NameOfItem = rm.NameOfItem;
            a.MenuID = rm.MenuID;
            a.UserID = RestaurentRepository.GetUserId();
            RestaurentRepository.AddToCart(a);
            RestaurentRepository.AddCartD(a);
            return View("RestaurentCartView",RestaurentRepository.Cart);

        }
        public ViewResult Index()
        {
            return View("Index");
        }
       
            [HttpGet]
        public ViewResult UserSignUp()
        {
            return View("UserSignUp");

        }
        [HttpPost]
        public ViewResult UserSignUp(User u)
        {

            if (ModelState.IsValid)
            {
                foreach (User u1 in RestaurentRepository.user)
                {
                    if (u1.UserID == u.UserID)
                    {
                        ModelState.AddModelError(string.Empty, "Login already exist");
                        RestaurentRepository.REmoveUserId();

                        return View("UserSignUp");
                    }
                }
                //RestaurentRepository.AddRestaurent(r);
                //RestaurentRepository.SetRestaurentId(r.RestaurentID);
                //ViewBag.r = r;
                RestaurentRepository.SetUserId(u.UserID);
                return View("RestaurentHomePage");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "please enter correct data");
                RestaurentRepository.REmoveUserId();
                return View("UserSignUp");

            }

        }
        [HttpGet]
        public ViewResult RestaurentHomePage()
        {

            return View("RestaurentHomePage");
        }
        [HttpGet]
        public ViewResult RestaurentMenue(string RestaurentID)
        {
            RestaurentRepository.SetRestaurentId(RestaurentID);
            return View("RestaurentMenue", RestaurentRepository.restaurentsMenu);
            //RestaurentMenu rm = RestaurentRepository.restaurentsMenu.Find(r => r.RestaurentID == RestaurentID);


        }
        //[HttpPost]
        //public ViewResult RestaurentMenue(RestaurentMenu rm)
        //{
        //    return View("RestaurentMenue", RestaurentRepository.restaurentsMenu);
        //}
        [HttpGet]
        public ViewResult RestaurentList()
        {
            

            return View("RestaurentList", RestaurentRepository.restaurents);
        }
      
             [HttpGet]
        public ViewResult Back()
        {
            RestaurentRepository.REmoveRestaurentId();

            return View("RestaurentList", RestaurentRepository.restaurents);
        }
        [HttpGet]
        public ViewResult RestaurentCartView()
        {

            return View("RestaurentCartView", RestaurentRepository.Cart);
        }
        [HttpGet]
        public ViewResult RestaurentContactUs()
        {
            return View("RestaurentContactUs");
        }
        [HttpGet]
        public ViewResult MenueDetail(string RestaurentID, int MenuID)
        {
            RestaurentMenu rm = RestaurentRepository.restaurentsMenu.Find(rm => rm.RestaurentID == RestaurentID && rm.MenuID == MenuID);
           
            return View("MenueDetail",rm);
        }
      
    }
}
