﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
namespace FinalYearProjet.Models
{
    public static class RestaurentRepository
    {
        public static List<Restaurent> restaurents = new List<Restaurent>();
        public static List<RestaurentMenu> restaurentsMenu = new List<RestaurentMenu>();
        public static List<User> user = new List<User>();
        public static List<Receipt> restaurantOrderList = new List<Receipt>();
        public static List<Receipt> restaurantPendingOrder = new List<Receipt>();
        public static List<CartAndOrder> Cart = new List<CartAndOrder>();
        public static List<CartAndOrder> order = new List<CartAndOrder>();

        public static List<Receipt> receipts = new List<Receipt>();
        public static List<String> id = new List<string>();
        public static List<String> Userid = new List<string>();

        static SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB; Initial Catalog = RestaurentDB; Integrated Security = True; Connect Timeout = 30; Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        static RestaurentRepository()
        {
            //try
            //{
            //    con.Open();
            //    string query = $"delete from Orders";
            //    SqlCommand cmd = new SqlCommand(query, con);
            //    int no = cmd.ExecuteNonQuery();

            //}
            //catch (Exception e)
            //{

            //}
            //finally
            //{
            //    con.Close();
            //}
            // restaurents.Add(new Restaurent{ RestaurentID="f19@gmail.com", NameOfRestaurants= "fatima", Location="bahar town", PhoneNo="09786575234", OpenUntil = "12pm", DeliveryCharges="0", PhotoPATH="", Password="098" }); 
            //Restaurant database
            try
            {
                con.Open();
                string query = $"Select * from Restaurent";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Restaurent r = new Restaurent();
                    r.RestaurentID = dr.GetValue(0).ToString();
                    r.NameOfRestaurants = dr.GetValue(1).ToString();
                    r.Location = dr.GetValue(2).ToString();
                    r.PhoneNo = dr.GetValue(3).ToString();
                    r.OpenUntil = dr.GetValue(4).ToString();
                    r.DeliveryCharges = dr.GetValue(5).ToString();
                    r.PhotoPATH = dr.GetValue(6).ToString();
                    r.Password = dr.GetValue(7).ToString();
                    restaurents.Add(r);
                }
            }
            catch (Exception)
            {

            }
            finally
            {
                con.Close();
            }
            restaurentsMenu.Add(new RestaurentMenu { MenuID=1, RestaurentID = "f19@gmail.com", NameOfItem = "buryani", Price = "1000", Quantity =2 , PhotoPATH2 = "", unit = "box" });
            //Cart View
            try
            {
                con.Open();
                string query = $"Select * from Cart";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    CartAndOrder r = new CartAndOrder();
                    r.CartID = dr.GetInt32(0);
                    r.RestaurentID = dr.GetValue(1).ToString();
                    r.MenuID = dr.GetInt32(2);
                    r.UserID = dr.GetValue(3).ToString();
                    r.NameOfItem = dr.GetValue(4).ToString();
                    r.Price = dr.GetValue(5).ToString();
                    r.OriginalPrice = dr.GetValue(6).ToString();
                    r.Quantity = dr.GetInt32(7);
                    Cart.Add(r);


                }
            }
            catch (Exception)
            {

            }
            finally
            {
                con.Close();
            }
            //ORDER database

            try
            {
                con.Open();
                string query = $"Select * from Orders";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    CartAndOrder r = new CartAndOrder();
                    r.CartID = dr.GetInt32(0);
                    r.RestaurentID = dr.GetValue(1).ToString();
                    r.MenuID = dr.GetInt32(2);
                    r.UserID = dr.GetValue(3).ToString();
                    r.NameOfItem = dr.GetValue(4).ToString();
                    r.Price = dr.GetValue(5).ToString();
                    r.OriginalPrice = dr.GetValue(6).ToString();
                    r.Quantity = dr.GetInt32(7);
                    r.ReceiptID = dr.GetInt32(8);
                    order.Add(r);
                }
            }
            catch (Exception e)
            {

            }
            finally
            {
                con.Close();
            }
            //Receipt database

            try
            {
                con.Open();
                string query = $"Select * from Receipt";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
 



                    Receipt r = new Receipt();
                    r.ReceiptID = dr.GetInt32(0);
                    r.UserID = dr.GetValue(1).ToString();
                    r.RestaurentID = dr.GetValue(2).ToString();
                    r.TotalAmount = dr.GetValue(3).ToString();
                    r.NoOfItems = dr.GetInt32(4);
                    r.UserTime = dr.GetValue(5).ToString();
                    r.OrderTime = dr.GetDateTime(6);
                    r.OrderAccept = dr.GetInt32(7);
                    r.OrderReceived = dr.GetInt32(9);
                    //r.UserTime = dr.GetValue(10).ToString();
                    if (r.OrderAccept == 0)
                    {
                        restaurantPendingOrder.Add(r);
                    }
                    else
                    {
                        restaurantOrderList.Add(r);
                    }

                }
            }
            catch (Exception e)
            {

            }
            finally
            {
                con.Close();
            }
            //Restaurant Menu Database
            try
            {
                con.Open();
                string query = $"Select * from RestaurentMenu";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    RestaurentMenu r = new RestaurentMenu();
                    r.MenuID = dr.GetInt32(0);
                    r.RestaurentID = dr.GetValue(1).ToString();
                    r.NameOfItem = dr.GetValue(2).ToString();
                    r.Price = dr.GetValue(3).ToString();
                    r.Quantity = dr.GetInt32(4);
                    r.PhotoPATH2 = dr.GetValue(5).ToString();
                    r.unit = dr.GetValue(6).ToString();
                    restaurentsMenu.Add(r);
                }
            }

            catch (Exception)
            {

            }
            finally
            {
                con.Close();
            }
        }



         public static void SetRestaurentId(String Id)
        {
            id.Add(Id);

        }
        public static void REmoveRestaurentId()
        {
            bool isEmpty = !id.Any();
            if (isEmpty) ;
            else
                id.Remove(id[0]);


        }
        public static void SetUserId(String Id)
        {
            Userid.Add(Id);

        }
        public static void REmoveUserId()
        {
            bool isEmpty = !Userid.Any();
            if (isEmpty);
            else
                Userid.Remove(Userid[0]);


        }
        //Add Restaurant in database
        public static void AddRestaurentD(Restaurent r)
        {
            try
            {
                con.Open();
                string query = $"insert into Restaurent(RestaurentID,NameOfRestaurants,Location,PhoneNo,OpenUntil,DeliveryCharges,PhotoPATH,Password) values('{r.RestaurentID}','{r.NameOfRestaurants}','{r.Location}','{r.PhoneNo}','{r.OpenUntil}','{r.DeliveryCharges}','{r.PhotoPATH}', '{r.Password}') ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception )
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Add Menu in database
        public static void AddMenuD(RestaurentMenu r)
        {
            try
            {
                con.Open();
                string query = $"insert into RestaurentMenu(RestaurentID,NameOfItem,Price,Quantity,PhotoPATH2,unit) values('{r.RestaurentID}','{r.NameOfItem}','{r.Price}','{r.Quantity}','{r.PhotoPATH2}','{r.unit}' ) ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Add to cart in database
        public static void AddCartD(CartAndOrder r)
        {
            try
            {
                con.Open();
                string query = $"insert into Cart(RestaurentID,MenuID,UserID,NameOfItem,Price,OriginalPrice,Quantity) values('{r.RestaurentID}','{r.MenuID}','{r.UserID}','{r.NameOfItem}','{r.Price}','{r.OriginalPrice}', '{r.Quantity}') ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Add Order in database
        
        public static void AddOrderD(CartAndOrder r)
        {
            try
            {
                con.Open();
                //$"insert into Cart(RestaurentID,MenuID,UserID,NameOfItem,Price,OriginalPrice,Quantity) values('{r.RestaurentID}','{r.MenuID}','{r.UserID}','{r.NameOfItem}','{r.Price}','{r.OriginalPrice}', '{r.Quantity}') ";
                string query = $"insert into Orders(RestaurentID,MenuID,UserID,NameOfItem,Price,OriginalPrice,Quantity,ReceiptID) values('{r.RestaurentID}','{r.MenuID}','{r.UserID}','{r.NameOfItem}','{r.Price}','{r.OriginalPrice}', '{r.Quantity}','{r.ReceiptID}') ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();
               
            }
            catch (Exception e)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Add Receipt in database
        //                   ReceiptID   int False

        //   UserID varchar(50)	True
        //  RestaurentID    varchar(50) True
        //  TotalAmount varchar(50) True
        //  NoOfItems   int True

        //   UserTime varchar(50)	True
        //OrderTime   datetime True

        //   OrderAccept int True

        //   OrderReceived   int True

        public static void AddReceiptD(Receipt r)
        {
            try
            {
                con.Open();
                //$"insert into Cart(RestaurentID,MenuID,UserID,NameOfItem,Price,OriginalPrice,Quantity) values('{r.RestaurentID}','{r.MenuID}','{r.UserID}','{r.NameOfItem}','{r.Price}','{r.OriginalPrice}', '{r.Quantity}') ";
                string query = $"insert into Receipt(ReceiptID,UserID,RestaurentID,TotalAmount,NoOfItems,UserTime,OrderTime,OrderAccept,OrderReceived) values('{r.ReceiptID}','{r.UserID}','{r.RestaurentID}','{r.TotalAmount}','{r.NoOfItems}','{r.UserTime}', '{r.OrderTime}','{r.OrderAccept}','{r.OrderReceived}') ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();

            }
            catch (Exception e)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Remove restaurant from Databse
        public static void RemoveRestaurent(string RestaurentID)
        {
            try
            {
                con.Open();
                string query = $"delete from Restaurent where RestaurentID='{RestaurentID}'";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Remove Menu from Databse
        public static void RemoveMenu(string RestaurentID, int MenuID)
        {
            try
            {
                con.Open();
                string query = $"delete from RestaurentMenu where RestaurentID='{RestaurentID}' and MenuID='{MenuID}' ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Remove Cart From Database
      
        public static void RemoveCart(int CartID)
        {
            try
            {
                con.Open();
                string query = $"delete from Cart where CartID='{CartID}'";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Remove Order from database
        public static void RemoveOrder(int CartID)
        {
            try
            {
                con.Open();
                string query = $"delete from Orders where CartID='{CartID}'";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Remove Receipt from database
        public static void RemoveReceipt(int ReceiptID)
        {
            try
            {
                con.Open();
                string query = $"delete from Receipt where ReceiptID='{ReceiptID}'";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Update restaurant in Databse
        public static void EditRestaurent(Restaurent r)
        {
            try
            {
                con.Open();
                string query = $"update Restaurent set NameOfRestaurants='{r.NameOfRestaurants}',Location='{r.Location}',PhoneNo='{r.PhoneNo}',OpenUntil='{r.OpenUntil}',DeliveryCharges='{r.DeliveryCharges}', PhotoPATH='{r.PhotoPATH}',Password='{r.Password}' where RestaurentID='{r.RestaurentID}'  ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Update Menu in Databse
        public static void EditMenu(RestaurentMenu r)
        {
            try
            {
                con.Open();
                string query = $"update RestaurentMenu set NameOfItem='{r.NameOfItem}',Price ='{r.Price}',Quantity ='{r.Quantity}', PhotoPATH2='{r.PhotoPATH2}',unit='{r.unit}' where RestaurentID='{r.RestaurentID}' and    MenuID='{r.MenuID}'";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {


            }
            finally
            {
                con.Close();
            }

        }
        //Update Cart in database
        public static void EditCart(CartAndOrder r)
        {
            try
            {
                con.Open();
                string query = $"update Cart set Price='{r.Price}',Quantity='{r.Quantity}' where CartID='{r.CartID}'  ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {


            }
            finally
            {
                con.Close();
            }

        }

        ////Update Order in database
        //public static void EditOrder(CartAndOrder r)
        //{
        //    try
        //    {
        //        con.Open();
        //        string query = $"update Orders set OrderAccept='{r.OrderAccept}' where ID='{r.CartID}'  ";
        //        SqlCommand cmd = new SqlCommand(query, con);
        //        int no = cmd.ExecuteNonQuery();


        //    }
        //    catch (Exception e)
        //    {


        //    }
        //    finally
        //    {
        //        con.Close();
        //    }

        //}
        //Update Receipt in database
        public static void EditReceipt(Receipt r)
        {
            try
            {
                con.Open();
                string query = $"update Receipt set OrderAccept='{r.OrderAccept}' where ID='{r.ReceiptID}'  ";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {


            }
            finally
            {
                con.Close();
            }

        }

        //Clear All Cart From Database

        public static void ClearAllCart()
        {
            try
            {
                con.Open();
                string query = $"delete from Cart";
                SqlCommand cmd = new SqlCommand(query, con);
                int no = cmd.ExecuteNonQuery();


            }
            catch (Exception)
            {


            }
            finally
            {
                con.Close();
            }

        }

        public static string GetRestaurentId()
        {
            return id[0];

        }
        public static string GetUserId()
        {
            return Userid[0];

        }
        public static void AddRestaurent(Restaurent r)
        {

            restaurents.Add(r);
            AddRestaurentD(r);
        }
        public static void AddToCart(CartAndOrder a)
        {
            Cart.Add(a);
        }
        public static void AddRestaurentMenu(RestaurentMenu rm)
        {
            rm.MenuID = restaurentsMenu.Count+1;
            restaurentsMenu.Add(rm);
            AddMenuD(rm);
        }
    }
}
