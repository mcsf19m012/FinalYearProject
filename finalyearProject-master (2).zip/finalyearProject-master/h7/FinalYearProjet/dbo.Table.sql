﻿CREATE TABLE [dbo].[Receipt]
(
	[ReceiptID] INT NOT NULL PRIMARY KEY, 
    [UserID] VARCHAR(50) NULL, 
    [RestaurentID] VARCHAR(50) NULL, 
    [TotalAmount] VARCHAR(50) NULL, 
    [NoOfItems] INT NULL, 
    [UserTime] VARCHAR(50) NULL, 
    [OrderTime] DATETIME NULL, 
    [OrderAccept] INT NULL, 
    [OrderReceived] INT NULL
)
