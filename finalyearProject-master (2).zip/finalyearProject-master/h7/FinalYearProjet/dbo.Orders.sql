﻿CREATE TABLE [dbo].[Orders] (
    [ID]            INT          IDENTITY (1, 1) NOT NULL,
    [RestaurentID]  VARCHAR (50) NULL,
    [MenuID]        INT          NULL,
    [UserID]        VARCHAR (50) NULL,
    [NameOfItem]    VARCHAR (50) NULL,
    [Price]         VARCHAR (50) NULL,
    [OriginalPrice] VARCHAR (50) NULL,
    [Quantity]      INT          NULL,
    [OrderAccept]   INT          NULL,
    [OrderReceived] INT          NULL,
    [UserTime]      VARCHAR (50) NULL,
    [ReceiptId] INT NOT NULL, 
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

